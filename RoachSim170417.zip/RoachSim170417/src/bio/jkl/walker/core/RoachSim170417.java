package bio.jkl.walker.core;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.xml.datatype.DatatypeConfigurationException;

import bio.jkl.walker.biology.AgentProperties;
import bio.jkl.walker.heuristics.Walker;
import bio.jkl.walker.heuristics.Walker_Bilateral;
import bio.jkl.walker.heuristics.Walker_Integration;
import bio.jkl.walker.heuristics.Walker_Limited;
import bio.jkl.walker.heuristics.Walker_Random;
import bio.jkl.walker.heuristics.Walker_SpatioTemporal;
import bio.jkl.walker.heuristics.Walker_Temporal;
import bio.jkl.walker.physics.OdorFactory;
import bio.jkl.walker.physics.WorldProperties;
import bio.jkl.walker.utils.DynamicPlotTrackHistory;

public class RoachSim170417 {

	// counters to keep track of multiple trials with multiple parameters
	private static int trialNumber = 0;
	private static int nTrials = 100; // how many of each parameter combo?
	private static int antennaComboNumber = 0; //
	private static int gainFactorNumber = 0;
	private static int heuristicNumber = 5;
	private static int nHeuristics = 6; // how many heuristics?
	private static boolean moreTrials = true; // are their more trials to run?

	// graphics
	private static boolean runGraphics = false;
	private static DynamicPlotTrackHistory plot;

	// agent, plume, and properties, these will be initialized later for each
	// trial:
	private static Walker HAL;
	private static OdorFactory plumeFactory;
	private static AgentProperties agentProperties;
	private static WorldProperties worldProperties;

	// logging data. Most will be initialized later, once for each parameter
	// set.
	private static FileWriter successTable;
	private static String saveFolder;
	private static String parentFolder = "/media/jacob/Boron/walkerData/";

	public static void main(String[] args) throws IOException, DatatypeConfigurationException, InterruptedException {

		setSaveDirectory();

		while (moreTrials) {
			runTrial();
		}
	}

	private static String getDateString() {

		// grab the current time from the system and return a useful string to
		// stamp on any files we create
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd_HH:mm:ss");
		String formattedDate = sdf.format(new Date());

		return formattedDate;
	}

	private static void printSettingToFile(String fname, boolean print2Console) throws IOException {
		File directory = new File(fname);
		directory.mkdir();
		FileWriter writer = new FileWriter(fname + "/parameters.txt");
		PrintWriter print_line = new PrintWriter(writer);
		print_line.println("Agent Properties:");
		print_line.println("    heuristic           = " + HAL.talk());
		print_line.println("    odorON/odorOFF      = " + agentProperties.odorONOFF);
		print_line.println("    rightAntenna        = " + HAL.rightAntenna.length);
		print_line.println("    leftAntenna         = " + HAL.leftAntenna.length);
		print_line.println("    detectionThreshold  = " + agentProperties.detectionThreshold);
		print_line.println("    emissionRate        = " + worldProperties.emissionRate);
		print_line.println("    heuristicGainFactor = " + agentProperties.heuristic_gainFactor);
		print_line.println("    randGainFactor      = " + agentProperties.random_gainFactor);
		print_line.println("    decayRate           = " + agentProperties.decayRate);
		print_line.println("    evidenceThreshold   = " + agentProperties.evidenceThreshold);

		print_line.close();

		// create a new success table
		successTable = new FileWriter(fname + "/successTable.csv", true);

		if (print2Console) {
			System.out.println("This trial has the following agent properties:");
			System.out.println("    heuristic           = " + HAL.talk());
			System.out.println("    odorON/odorOFF      = " + agentProperties.odorONOFF);
			System.out.println("    rightAntenna        = " + HAL.rightAntenna.length);
			System.out.println("    leftAntenna         = " + HAL.leftAntenna.length);
			System.out.println("    detectionThreshold  = " + agentProperties.detectionThreshold);
			System.out.println("    emissionRate        = " + worldProperties.emissionRate);
			System.out.println("    heuristicGainFactor = " + agentProperties.heuristic_gainFactor);
			System.out.println("    randGainFactor      = " + agentProperties.random_gainFactor);
			System.out.println("    decayRate           = " + agentProperties.decayRate);
			System.out.println("    evidenceThreshold   = " + agentProperties.evidenceThreshold);
		}

	}

	private static void runTrial() throws IOException, DatatypeConfigurationException, InterruptedException {
		// step 1: setup
		setupWorld();

		setupAgent();

		if (runGraphics) {
			setupPlot();
		}

		HAL.startTracking();

		int frame = 0;
		do {
			frame++;

			// step 2: update the plume:
			updatePlume(frame);

			// Step 3: collect & process information
			HAL.updateAntennalMap(plumeFactory.plume);

			// Step 4: update turning rate, theta-dot
			HAL.adjustAngularVelocity();

			// Step 5: update position
			HAL.step();
			if (runGraphics) {
				plot.refreshData(HAL.headPt, HAL.tailPt, HAL.leftAntenna.base, HAL.leftAntenna.tip,
						HAL.rightAntenna.base, HAL.rightAntenna.tip, plumeFactory.plume);
			}

			if (frame % 100 == 0) {
				System.out.print(".");
			}

			// step 6: check for termination conditions
		} while (HAL.walkerRunning);

		// Step 7: end trial and log everything to file
		HAL.saveData(parentFolder + saveFolder + "/trial_", trialNumber);
		trialResultOutput();

		if (runGraphics) {

			Scanner reader = new Scanner(System.in); // Reading from System.in
			System.out.println("ready to save track?");
			String response = reader.next();
			if (response.equalsIgnoreCase("y")) {
				/*
				 * this solves the series out of bounds error, if I wait long
				 * enough before hitting "y"...so methinks the problem has
				 * something to do with trying to save the chart before
				 * everything has been written to it...
				 */
				plot.savePNG(parentFolder + saveFolder + "/trial_", trialNumber);
			}
			reader.close();

			plot.dispose();
		}

		trialNumber++; // advance the trial number
	}

	private static void setSaveDirectory() {
		saveFolder = getDateString();
		File dir = new File(parentFolder + saveFolder);
		boolean successful = dir.mkdir();
		if (successful) {
			System.out.println("data will be written to: ");
			System.out.println(parentFolder + saveFolder);
		}
	}

	private static void setupAgent() throws IOException, DatatypeConfigurationException {

		// parameter setup:
		agentProperties = new AgentProperties();

		// advance the collection of parameters:
		if (trialNumber == nTrials) {
			successTable.close();
			trialNumber = 0;
			antennaComboNumber++;
			setSaveDirectory(); // but each new group of parameters into it's
								// own folder

			if (antennaComboNumber == agentProperties.n_antennaLengths) {
				antennaComboNumber = 0;
				gainFactorNumber++;

				if (gainFactorNumber == agentProperties.n_gainFactors) {
					gainFactorNumber = 0;
					heuristicNumber++;

					if (heuristicNumber == nHeuristics) {
						// end the program
						System.out.println("Fin");
						moreTrials = false;
					}
				}
			}
		}

		// set some parameters:
		agentProperties.setAntennaLength(antennaComboNumber);
		agentProperties.setGainFactors(gainFactorNumber);

		// agent setup:
		switch (heuristicNumber) {
		case 1:
			HAL = new Walker_Limited(agentProperties, worldProperties);
			break;
		case 2:
			HAL = new Walker_Bilateral(agentProperties, worldProperties);
			break;
		case 3:
			HAL = new Walker_Temporal(agentProperties, worldProperties);
			break;
		case 4:
			HAL = new Walker_Integration(agentProperties, worldProperties);
			break;
		case 5:
			HAL = new Walker_SpatioTemporal(agentProperties, worldProperties);
			break;
		default:
			HAL = new Walker_Random(agentProperties, worldProperties);
			break;
		}

		if (trialNumber == 0) {
			printSettingToFile(parentFolder + saveFolder, true);
			System.out.print("Plume ready.");
		}

	}

	private static void setupPlot() {
		// plot setup:
		plot = new DynamicPlotTrackHistory("Tracking History", worldProperties, agentProperties);
		plot.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		plot.pack();
		plot.setLocationRelativeTo(null);
		plot.setVisible(true);
	}

	private static void setupWorld() throws IOException, DatatypeConfigurationException {

		// parameter setup:
		double dt = 0.010; // time-step in s
		double emissionRate = 0.9; // probability an odor particle is created
									// each time-step
		worldProperties = new WorldProperties(dt, emissionRate);

		// plume setup:
		plumeFactory = new OdorFactory(worldProperties);

		// get plume ready:
		do {
			updatePlume((int) 0); // this will be the 0th frame
		} while (!plumeFactory.plumeReady);
		if (trialNumber > 0) {
			System.out.print("Plume ready.");
		}
	}

	private static void trialResultOutput() throws IOException {
		// TODO Auto-generated method stub
		successTable.append(Integer.toString(trialNumber));
		successTable.append(",");

		if (HAL.foundSource) {
			System.out.println("found source!");
			successTable.append("1");
		} else if (HAL.timeout) {
			System.out.println("Timed out.");
			successTable.append("-1");

		} else {
			System.out.println("left arena.");
			successTable.append("0");
		}
		successTable.append("\n");
		successTable.flush();

	}

	private static void updatePlume(int frame) throws DatatypeConfigurationException {
		// move the plume one time-step:
		plumeFactory.run(Integer.toString(frame));

		// just try to get the basic random walking plume particle back...
		// plot.plumeData2Draw(plumeFactory.plume);

	}

}
