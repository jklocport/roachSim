/**
 * 
 */
/**
 * @author jacob
 *
 */
package bio.jkl.walker.core;