package bio.jkl.walker.physics;

import java.util.ArrayList;
import java.util.Random;

import javax.xml.datatype.DatatypeConfigurationException;

public class OdorFactory {

	// creates, manages, and removes odor particles

	public ArrayList<OdorParticle> plume;
	public boolean plumeReady;
	private WorldProperties worldProp;
	private Random rand;

	public OdorFactory(WorldProperties worldProp_) {
		// TODO Auto-generated constructor stub

		plume = new ArrayList<OdorParticle>();
		worldProp = worldProp_;
		rand = new Random();

		plumeReady = false;
	}

	public void run(String ID) throws DatatypeConfigurationException {
		// returns a string ListArray containing the IDs of the particles
		// removed, to feed into the plotting function for removal from the plot
		// chart
		// create new odor particle:
		if (rand.nextDouble() <= worldProp.emissionRate) {
			plume.add(new OdorParticle(ID, worldProp));
		}

		// move all odor particles
		for (int i = plume.size() - 1; i >= 0; i--) { // loop
														// backwards
														// through
														// ArrayList
			OdorParticle op = plume.get(i);
			try {
				op.propagate();
			} catch (DatatypeConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			if (op.center.x < 0) {
				plumeReady = true;
				plume.remove(i);
			}

		}
	}
}
