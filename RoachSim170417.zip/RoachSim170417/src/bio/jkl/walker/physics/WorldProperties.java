package bio.jkl.walker.physics;

import javax.xml.datatype.DatatypeConfigurationException;

public class WorldProperties {

	/*
	 * The purpose here is to have a object that holds a collection of
	 * parameters and can be passed around
	 */

	// lay out the geometry (in mm) of the arena
	public double height = 925; // mm, cross-wind direction
	public double width = 1525; // mm, up/down-wind direction
	public PVector source = new PVector(width, height / 2);;

	public double dt;

	// wind and plume statistics:
	public double windSpeed = -250; // mm/s, to the left
	public double emissionRate; // proportion of the time a new odor particle
								// should be generated
	public double startingConcentration = 0.0201821; // volts, estimated from
														// PID recordings
	public double dcdx = -0.0000143241; // volts / mm, rate of concentration
										// drop as we go down wind
	public double dydx_plume = 0.156364; // rate of growth of the plume width

	// TODO: insert new values based on latest PID recordings
	// constants for natural decay of the plume:
	public double n_naught = 3.6737; // Initial value of plume concentration
	public double lambda = 0.00174666;// decay rate

	public WorldProperties(double dt_, double emissionRate_) throws DatatypeConfigurationException {

		dt = dt_;

		emissionRate = emissionRate_; // should be a decimal

		checkValues();

	}

	private void checkValues() throws DatatypeConfigurationException {
		// make sure the emissionRate is between 0 and 1 (inclusive)
		if (emissionRate > 1) {
			throw new DatatypeConfigurationException("emissionRate must be <= 1");
		} else if (emissionRate < 0) {
			throw new DatatypeConfigurationException("emissionRate must be > 0");
		}

		if (dt < 0) {
			throw new DatatypeConfigurationException("timesteps (dt) must be positive");
		}
	}

}
