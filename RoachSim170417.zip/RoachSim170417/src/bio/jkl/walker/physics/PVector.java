package bio.jkl.walker.physics;

import javax.xml.datatype.DatatypeConfigurationException;

public class PVector {

	public double x = 0;
	public double y = 0;
	public double z = 0;

	public int dimensions;

	// 1D version
	public PVector(double x_) {
		x = x_;
		dimensions = 1;
	}

	// 2D version
	public PVector(double x_, double y_) {
		x = x_;
		y = y_;
		dimensions = 2;
	}

	// 3D version
	public PVector(double x_, double y_, double z_) {
		x = x_;
		y = y_;
		z = z_;
		dimensions = 3;

	}

	/************************************************************************
	 * public class methods:
	 * 
	 * add(PVector addition); // updates this PVector
	 * 
	 * cross(PVector crossVector); // returns a new PVector
	 * 
	 * distance(PVector target); // returns a double
	 * 
	 * dot(PVector dotVector); // returns a double
	 * 
	 * multiplyScalor(double s); // updates this PVector
	 * 
	 * print(); // returns a string
	 * 
	 **********************************************************************/

	public void add(PVector addition) throws DatatypeConfigurationException {
		checkDimensions(addition);
		// basic vector addition
		x += addition.x;
		y += addition.y;
		z += addition.z;
	}

	public PVector cross(PVector crossVector) throws DatatypeConfigurationException {
		// returns the cross product of this vector crossed with crossVector
		checkDimensions(crossVector);
		double x_comp = y * crossVector.z - z * crossVector.y;
		double y_comp = z * crossVector.x - x * crossVector.z;
		double z_comp = x * crossVector.y - y * crossVector.x;

		return new PVector(x_comp, y_comp, z_comp);
	}

	public double distance(PVector targetPt) throws DatatypeConfigurationException {
		// distance between each directional vector
		checkDimensions(targetPt);

		double dx = x - targetPt.x;
		double dy = y - targetPt.y;
		double dz = z - targetPt.z;

		double sumOfSquares = dx * dx + dy * dy + dz * dz;

		double span = Math.sqrt(sumOfSquares);

		return span;
	}

	public double dot(PVector dotVector) throws DatatypeConfigurationException {
		checkDimensions(dotVector);
		// dot product
		double dotProduct = x * dotVector.x + y * dotVector.y + z * dotVector.z;
		return dotProduct;
	}

	public void multiplyScalor(double s) {
		x = x * s;
		y = y * s;
		z = z * s;
	}

	public String print() {
		// simple function to return a neatly formatted string of the contents
		// of the PVector
		String outputText;
		switch (dimensions) {
		case 1:
			outputText = "(" + x + ")";
			break;
		case 2:
			outputText = "(" + x + ", " + y + ")";
			break;
		case 3:
			outputText = "(" + x + ", " + y + ", " + z + ")";
			break;
		default:
			outputText = "PVector has not been initzalized";
			break;
		}

		return outputText;
	}

	/************************************************************************
	 * private class methods:
	 * 
	 * checkDimensions(PVector otherVector);
	 * 
	 **********************************************************************/

	private void checkDimensions(PVector otherVector) throws DatatypeConfigurationException {
		// check if the dimensions of the inputed vector matches this one
		if (dimensions != otherVector.dimensions) {
			// throw an exception
			throw new DatatypeConfigurationException("demensions of PVectors do not match");
		}
	}

}
