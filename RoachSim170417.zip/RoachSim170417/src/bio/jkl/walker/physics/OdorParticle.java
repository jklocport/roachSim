package bio.jkl.walker.physics;

import java.util.Random;

import javax.xml.datatype.DatatypeConfigurationException;

public class OdorParticle {

	public PVector center;
	public double radius;
	public double concentration;
	private double areaPrime; // starting size of the odor blob

	private double dxdt;
	private double dydt;
	private PVector velocity;
	private WorldProperties worldProp;

	public String ID;

	public OdorParticle(String ID_, WorldProperties worldProp_) {
		worldProp = worldProp_;
		ID = ID_; // a unique identifier for handling plotting

		center = new PVector(worldProp.source.x, worldProp.source.y);
		radius = 3; // diameter of source

		concentration = worldProp.n_naught;

		dxdt = worldProp.windSpeed * worldProp.dt; // down wind step size for
													// each time step
		dydt = -dxdt * worldProp.dydx_plume; // based on how far down wind we've
												// gone, move cross wind

		int n = Double.toString(dydt).length(); // length of double
		double factor = Math.pow(10, n); // a factor so we can work with ints
		int maxVel = (int) (dydt * factor); // move the decimal, recast as int

		Random rand = new Random();

		dydt = (((double) rand.nextInt(maxVel) - maxVel / 2)) / factor;
		// center about zero, (-maxVel/2), recast as a double, divide by factor
		// to go back to a decimal

		velocity = new PVector(dxdt, dydt);

		areaPrime = Math.PI * radius * radius; // pi * r^2
	}

	public void diffuse() {
		// lower the concentration
		// simple y=mx+b:
		concentration = worldProp.n_naught * Math.exp(-worldProp.lambda * (worldProp.source.x - center.x));

		// increase the area such that the total amount of mass is the same:
		double updatedArea = areaPrime * worldProp.n_naught / concentration;

		// update the diameter to match:
		radius = Math.sqrt(updatedArea / Math.PI) * 5;
	}

	public void propagate() throws DatatypeConfigurationException {

		center.add(velocity);// move the odor particle
		diffuse(); // get new concentration based on location
	}

}
