package bio.jkl.walker.utils;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.annotations.XYShapeAnnotation;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYBubbleRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.xy.DefaultXYZDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.Layer;

import bio.jkl.walker.biology.AgentProperties;
import bio.jkl.walker.physics.OdorParticle;
import bio.jkl.walker.physics.PVector;
import bio.jkl.walker.physics.WorldProperties;

public class DynamicPlotTrackHistory extends JFrame {

	/**
	 * Frankenstein code...sorry, it's pulled from many sources and heavily
	 * modified
	 * 
	 * This class is meant to provide a visual representation of the simulation.
	 * It provides no actual data for the simulation, so any mistakes here are
	 * only a problem if they lead me astray in fixing the simulation.
	 */
	private static final long serialVersionUID = 1L;
	private static final String title = "Agent Track History";
	private XYSeries trackSeries = new XYSeries("Head Point", false, true);
	private XYSeries bodySeries = new XYSeries("Body Position", false, true);
	public DefaultXYZDataset bubbleData = new DefaultXYZDataset();
	private ChartPanel chartPanel;

	private WorldProperties worldProperties;
	private AgentProperties agentProperties;
	private JFreeChart chart;

	private boolean isRunning = false;

	public DynamicPlotTrackHistory(String s, WorldProperties worldProperties_,
			AgentProperties agentProperties_) {
		// TODO: clean up & document code
		super(s);
		worldProperties = worldProperties_;
		agentProperties = agentProperties_;

		// final ChartPanel chartPanel = createDemoPanel();
		// createChart(createDataset());
		createChart(createDataset(trackSeries), bubbleData, createDataset(bodySeries));

		chartPanel = new ChartPanel(chart);
		this.add(chartPanel, BorderLayout.CENTER);
		chartPanel.getChart().removeLegend();
	}

	public void refreshData(PVector headPt, PVector tailPt, PVector lBase, PVector lTip, PVector rBase, PVector rTip,
			ArrayList<OdorParticle> plume) {
		// we only need one runner (extra thread?), nothing needs to be updated
		// until the agent is, so might as well make it this one
		Runnable runner = new Runnable() {
			@Override
			public void run() {
				SwingUtilities.invokeLater(new Runnable() {
					@Override
					public void run() {

						isRunning = true;
						// track history:
						trackSeries.add(headPt.x, headPt.y);

						// current body position:
						bodySeries.clear(); // remove all the points

						// update with new points, drawing a continuous line.
						// Need to double-back on one of the antenna so it looks
						// right
						bodySeries.add(tailPt.x, tailPt.y);
						bodySeries.add(headPt.x, headPt.y);
						bodySeries.add(lBase.x, lBase.y);
						bodySeries.add(lTip.x, lTip.y);
						bodySeries.add(lBase.x, lBase.y);
						bodySeries.add(rBase.x, rBase.y);
						bodySeries.add(rTip.x, rTip.y);

						// plume data
						// overwrite the old data
						for (int i = bubbleData.getSeriesCount() - 1; i >= 0; i--) {
							bubbleData.removeSeries(bubbleData.getSeriesKey(i));
						}
						OdorParticle op;
						for (int i = 0; i < plume.size(); i++) {
							op = plume.get(i);
							bubbleData.addSeries(Integer.toString(i),
									new double[][] { { op.center.x }, { op.center.y }, { op.radius } });
						}

						// //
						// SimpleDateFormat sdf = new SimpleDateFormat("mm:ss");
						// String r = sdf.format(new Date());
						// System.out.println("t:" + r);
					}
				});
				try {
					Thread.sleep(33);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		};
		new Thread(runner).start();

	}

	public void savePNG(String fname, int n) throws IOException, InterruptedException {

		// format the trial number to three digits:
		if (n < 10) {
			fname = fname + "00" + Integer.toString(n);
		} else if (n < 100) {
			fname = fname + "0" + Integer.toString(n);
		} else {
			fname = fname + Integer.toString(n);
		}

		File file_PNG = new File(fname + ".png");

		ChartUtilities.saveChartAsPNG(file_PNG, chart, chartPanel.getWidth(), chartPanel.getHeight());
	}

	private void createChart(final XYDataset trackData, final DefaultXYZDataset plumeData, final XYDataset bodyData) {
		/*
		 * create the plot & set the parameters.
		 * 
		 * This creates the ChartFactory, which sets the basic plotting features
		 * (title, axis, ect.).
		 */
		chart = ChartFactory.createXYAreaChart(title, "x", "y", trackData);
		// .createXYLineChart(title, "<--wind", "grid in mm", dataset,
		// PlotOrientation.VERTICAL, false,
		// true, false);

		XYPlot plot = chart.getXYPlot();

		plot.setDataset(0, trackData);
		plot.setDataset(1, plumeData);
		plot.setDataset(2, bodyData);

		XYLineAndShapeRenderer lineRenderer = new XYLineAndShapeRenderer();
		XYBubbleRenderer bubbleRenderer = new XYBubbleRenderer();
		XYLineAndShapeRenderer bodyRenderer = new XYLineAndShapeRenderer();

		// Set the size of the axes:
		NumberAxis domain = (NumberAxis) plot.getDomainAxis(); // domain
		domain.setRange(0.0, worldProperties.width);
		NumberAxis range = (NumberAxis) plot.getRangeAxis();
		range.setRange(0.0, worldProperties.height);
		range.setTickUnit(new NumberTickUnit(200));

		// control how the line looks:
		lineRenderer.setSeriesPaint(0, new Color(64, 64, 64));
		lineRenderer.setSeriesStroke(0, new BasicStroke(2.0f));
		lineRenderer.setBaseShapesVisible(false);
		lineRenderer.setDrawSeriesLineAsPath(true);
		plot.setRenderer(0, lineRenderer);

		// control how the bubbles look
		bubbleRenderer.setSeriesPaint(1, Color.GREEN);
		bubbleRenderer.setSeriesStroke(1, new BasicStroke(5.0f));
		bubbleRenderer.setSeriesFillPaint(1, Color.BLUE);

		// control how the body looks:
		bodyRenderer.setSeriesPaint(0, Color.RED);
		bodyRenderer.setSeriesStroke(0, new BasicStroke(2.0f));
		bodyRenderer.setBaseShapesVisible(false);
		bodyRenderer.setDrawSeriesLineAsPath(true);
		plot.setRenderer(2, bodyRenderer);

		plot.setRenderer(1, bubbleRenderer);

		// make a clean white background:
		plot.setBackgroundPaint(Color.WHITE);
		plot.setRangeGridlinesVisible(false);
		plot.setDomainGridlinesVisible(false);

		chart.setTitle(new TextTitle(title, new Font("Serif", Font.BOLD, 18)));

		// create a target and odor source marker
		//
		// set some parameters:
		Color sourceColor = new Color(185, 41, 229);
		Color targetColor = new Color(66, 244, 155);
		double sourceSize = 3; // source is 3mm in diameter
		double targetSize = agentProperties.bodyLength * 4; // need diameter
		// need to offset by half the size because the coordinate is for the
		// upper left corner of the bounding rectangle
		double sourcex = worldProperties.source.x - sourceSize / 2;
		double sourcey = worldProperties.source.y - sourceSize / 2;
		double targetx = worldProperties.source.x - targetSize / 2;
		double targety = worldProperties.source.y - targetSize / 2;

		// create the marker shapes to use as annotations:
		Shape targetMarkerShape = new Ellipse2D.Double(targetx, targety, targetSize, targetSize);
		Shape sourceMarkerShape = new Ellipse2D.Double(sourcex, sourcey, sourceSize, sourceSize);

		XYShapeAnnotation sourceMarker = new XYShapeAnnotation(sourceMarkerShape, new BasicStroke(2f), sourceColor,
				sourceColor);

		XYShapeAnnotation targetMarker = new XYShapeAnnotation(targetMarkerShape, new BasicStroke(0f), targetColor,
				targetColor);

		// draw the annotations:
		// use the renderer so we can assign a layer to the target
		lineRenderer.addAnnotation(targetMarker, Layer.BACKGROUND);
		plot.addAnnotation(sourceMarker); // the standard plotting layer is fine

		// turn off the legend

	}

	private XYDataset createDataset(XYSeries data) {
		// turn the XYseries into an XYSeriesCollection to use for plotting
		XYSeriesCollection xySeriesCollection = new XYSeriesCollection();
		xySeriesCollection.addSeries(data);
		return xySeriesCollection;
	}

}