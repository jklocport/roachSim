package bio.jkl.walker.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.opencsv.CSVReader;

public class CSVTable {

	public String[] columnNames;
	public List<String[]> entries;

	private CSVReader reader;

	public CSVTable(String filePath) throws FileNotFoundException, IOException {
		// TODO Auto-generated constructor stub
		reader = new CSVReader(new FileReader(filePath)); // create reader
															// object & open the
															// file
		entries = new ArrayList<String[]>(); // create a list to hold the data

		columnNames = reader.readNext(); // get the first line of the file
		String[] line = reader.readNext(); // get first line of data

		entries.add(line); // add the data to the list

		// continue adding data to the list until we have it all
		while ((line = reader.readNext()) != null) {
			entries.add(line);

		}

		reader.close(); // close the file
	}

}
