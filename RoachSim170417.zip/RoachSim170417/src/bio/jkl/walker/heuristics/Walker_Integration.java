package bio.jkl.walker.heuristics;

import javax.xml.datatype.DatatypeConfigurationException;

import bio.jkl.walker.biology.AgentProperties;
import bio.jkl.walker.physics.WorldProperties;

public class Walker_Integration extends Walker_Temporal {

	private double newTotalMass;
	private double massByDistance;
	private double newCenterOfMass;
	private double oldCenterOfMass;
	private boolean haveOdorContact;

	public Walker_Integration(AgentProperties agentProp_, WorldProperties worldProp_)
			throws DatatypeConfigurationException {
		super(agentProp_, worldProp_);
		// TODO Auto-generated constructor stub
		newTotalMass = 0;
		massByDistance = 0;
		newCenterOfMass = 0;
		oldCenterOfMass = 0;
		haveOdorContact = false;
	}

	@Override
	public void adjustAngularVelocity() {
		// find the barycenter of odor, or "mass":
		newTotalMass = leftAntenna.getOdorTotal() + rightAntenna.getOdorTotal();
		massByDistance = -leftAntenna.getMassByDistance() + rightAntenna.getMassByDistance();
		if (newTotalMass > 0) {
			newCenterOfMass = (1 / newTotalMass) * massByDistance;
			haveOdorContact = true;
		} else {
			haveOdorContact = false;
			newCenterOfMass = 0;
		}
		/*
		 * center of mass convention: -# is left, +# is right
		 */

		collectEvidence();
		// if (!firstVote) { // check that 1 threshold crossing = circle
		evaluateEvidence(); // this will update theta_dot if appropriate
		// }
		checkThetaDot(); // make sure we are within the limits of reality
		oldCenterOfMass = newCenterOfMass;
	}

	@Override
	public String talk() {
		return "integration";

	}

	private void collectEvidence() {

		if (haveOdorContact) {

			// this is remarkably simple, yet incredibly effective:
			// turn in the direction the center of mass moves, the weight of the
			// evidence is based on how far you are from facing up-wind

			if (newCenterOfMass > oldCenterOfMass) {
				// center of mass moved to the right
				goRight += Math.abs(theta / Math.PI); // scaled between 0 and 1

			} else if (newCenterOfMass < oldCenterOfMass) {
				// center of mass moved to the left
				goLeft += Math.abs(theta / Math.PI);

			} else {
				// center of mass didn't move
				goStraight += worldProp.dt;

			}

		} else {
			// no odor, go cross-wind in the opposite direction
			// this should create counter-turning
			if (theta > Math.PI / 2) {
				goLeft += 0.04;
			} else if (theta > 0) {
				goRight += 0.04;
			} else if (theta > -Math.PI / 2) {
				goLeft += 0.04;
			} else {
				goRight += 0.04;
			}
			// no goStraight, we've lost the plume, we want counter-turning, not
			// straight trajectories
		}

		// System.out.println(goLeft + ", " + goRight + ", " + goStraight);

	}

}
