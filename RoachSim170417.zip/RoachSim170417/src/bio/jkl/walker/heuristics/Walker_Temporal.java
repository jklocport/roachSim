package bio.jkl.walker.heuristics;

import javax.xml.datatype.DatatypeConfigurationException;

import bio.jkl.walker.biology.AgentProperties;
import bio.jkl.walker.physics.WorldProperties;

public class Walker_Temporal extends Walker_Limited {

	private double newMass = 0;
	private double oldMass = 0;
	protected double goLeft = 0;
	protected double goRight = 0;
	protected double goStraight = 0;
	protected boolean firstVote = false;

	public Walker_Temporal(AgentProperties agentProp_, WorldProperties worldProp_)
			throws DatatypeConfigurationException {
		super(agentProp_, worldProp_);
		// TODO Auto-generated constructor stub

	}

	@Override
	public void adjustAngularVelocity() {

		newMass = leftAntenna.getOdorTotal() + rightAntenna.getOdorTotal();

		collectEvidence();
		evaluateEvidence(); // this will update theta_dot if appropriate

		checkThetaDot(); // make sure we are within the limits of reality

		oldMass = newMass; // update for the next loop through
	}

	public void evaluateEvidence() {
		// evidence threshold is set to 1 (7 Feb. 2017)

		/*
		 * consider a leaky integrator.
		 */

		if (goLeft >= agentProp.evidenceThreshold) {
			omega += agentProp.ave_ang_vel;
			goLeft = 0;
			firstVote = true;
			// System.out.println("goLeft");
		}

		if (goRight >= agentProp.evidenceThreshold) {
			omega -= agentProp.ave_ang_vel;
			goRight = 0;
			firstVote = true;
			// System.out.println("goRight");
		}

		if (goStraight >= agentProp.evidenceThreshold) {
			omega /= 10; // get closer to zero
			goStraight = 0;
			firstVote = true;
			// System.out.println("goStraight");
		}

		// // decay information: (leak)
		// goLeft *= agentProp.decayRate;
		// goRight *= agentProp.decayRate;
		// goStraight *= agentProp.decayRate;
	}

	@Override
	public String talk() {
		return "temporal";

	}

	private void collectEvidence() {
		// double maxChange = rightAntenna.length + leftAntenna.length;

		/*
		 * This is presently (7 Feb 2017) over-simplified. The weighted values
		 * to add to each counter (goLeft, goRight, etc.) needs better
		 * justification.
		 * 
		 * This is better than what I had before: a smallLeft, smallRight,
		 * bigLeft...etc. and one of them was increased by 1 each loop.
		 * 
		 * Ideally, this would be done dynamically based on the amount of change
		 * in mass and by the specific heading relative to the wind
		 * 
		 * As per Brian Taylor's Thesis, it might also be nice to add in an
		 * error on the reading of the wind direction.
		 */

		if (newMass > oldMass) {
			// odor is increasing -- entering the plume?
			if (theta >= Math.PI / 2) {
				// up wind is behind and to the right
				goRight += 0.02;

			} else if (theta > 0) {
				// up wind is ahead and to the right
				goRight += 0.01;

			} else if (theta > -Math.PI / 2) {
				// up wind is ahead and to the left
				goLeft += 0.01;

			} else {
				// up wind is behind and to the left
				goLeft += 0.02;
			}

		} else if (newMass < oldMass) {
			// odor is decreasing -- leaving the plume?
			if (theta >= Math.PI / 2) {
				// up wind is behind and to the right, arcing left will lead
				// send you into the plume where it's wider
				goLeft += 0.04;

			} else if (theta > 0) {
				// up wind is ahead and to the right
				goRight += 0.02;

			} else if (theta > -Math.PI / 2) {
				// up wind is ahead and to the left
				goLeft += 0.02;

			} else {
				// up wind is behind and to the left
				goRight += 0.04;
			}

		} else {
			// no change in odor -- either outside or embedded in the plume
			goStraight += worldProp.dt; // 100 steps of no change, or 1 s
		}

	}

}
