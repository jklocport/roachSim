package bio.jkl.walker.heuristics;

import javax.xml.datatype.DatatypeConfigurationException;

import bio.jkl.walker.biology.AgentProperties;
import bio.jkl.walker.physics.WorldProperties;

public class Walker_Bilateral extends Walker_Limited {

	private int totalAntennaLength;

	public Walker_Bilateral(AgentProperties agentProp_, WorldProperties worldProp_)
			throws DatatypeConfigurationException {
		super(agentProp_, worldProp_);

		totalAntennaLength = leftAntenna.length + rightAntenna.length;

	}

	@Override
	public void adjustAngularVelocity() {
		// TODO Auto-generated method stub
		// super.adjustAngularVelocity();
		double leftMass = leftAntenna.getOdorTotal();
		double rightMass = rightAntenna.getOdorTotal();

		// this is what I had before, an acceleration:
		// theta_dot += agentProp.ave_ang_vel * (-leftMass + rightMass) / 40;

		// I'm now thinking this makes more sense:
		omega = agentProp.max_ang_vel * (-leftMass + rightMass) / totalAntennaLength;
		/*
		 * In the absence of information (left = right), theta_dot = 0, or in
		 * plain English: don't change your heading but go straight.
		 * 
		 * This assumes the agent knows how long it's antenna are.
		 */

		// decay:
		omega *= agentProp.decayRate;

		// testing: print values to console:
		// System.out.println(leftMass + ", " + rightMass + ", " + theta_dot);
		checkThetaDot(); // make sure we are within the limits of reality
	}

	@Override
	public String talk() {
		return "bilateral";

	}

}
