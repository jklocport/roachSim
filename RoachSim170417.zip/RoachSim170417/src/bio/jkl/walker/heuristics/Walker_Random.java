package bio.jkl.walker.heuristics;

import javax.xml.datatype.DatatypeConfigurationException;

import bio.jkl.walker.biology.AgentProperties;
import bio.jkl.walker.physics.WorldProperties;

public class Walker_Random extends Walker {

	public Walker_Random(AgentProperties agentProp_, WorldProperties worldProp_)
			throws DatatypeConfigurationException {
		super(agentProp_, worldProp_);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void adjustAngularVelocity() {
		// a true random walk:
		omega = (2 * rand.nextDouble() - 1) * Math.PI;
		// uniform distribution between -Pi & Pi

		// does a constant omega = circle? --> YES
		// omega = 0.5;
	}

	@Override
	public String talk() {
		return "random";
	}

}
