package bio.jkl.walker.heuristics;

import javax.xml.datatype.DatatypeConfigurationException;

import bio.jkl.walker.biology.AgentProperties;
import bio.jkl.walker.physics.WorldProperties;

public class Walker_Limited extends Walker {

	public Walker_Limited(AgentProperties agentProp_, WorldProperties worldProp_)
			throws DatatypeConfigurationException {
		super(agentProp_, worldProp_);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void adjustAngularVelocity() {
		// TODO Auto-generated method stub
		// super.adjustAngularVelocity();
		omega = (2 * rand.nextDouble() - 1) * agentProp.max_ang_vel;
		checkThetaDot();
	}

	public void checkThetaDot() {
		// check that our angular velocity it not greater than the maximum
		// possible
		if (omega > agentProp.max_ang_vel) {
			omega = agentProp.max_ang_vel;
		} else if (omega < -agentProp.max_ang_vel) {
			omega = -agentProp.max_ang_vel;
		}
	}

	@Override
	public String talk() {
		return "limited";

	}
}
