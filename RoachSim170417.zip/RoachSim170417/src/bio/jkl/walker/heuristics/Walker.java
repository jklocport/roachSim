package bio.jkl.walker.heuristics;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import javax.xml.datatype.DatatypeConfigurationException;

import com.opencsv.CSVWriter;

import bio.jkl.walker.biology.AgentProperties;
import bio.jkl.walker.biology.Antenna;
import bio.jkl.walker.physics.OdorParticle;
import bio.jkl.walker.physics.PVector;
import bio.jkl.walker.physics.WorldProperties;

public abstract class Walker {

	// body position, orientation, & parts
	public PVector headPt; // mm
	public PVector tailPt;
	public double speed = 0; // mm/s
	public double theta = 0; // rad
	public double omega = 0.0; // rad/s
	public Antenna leftAntenna;
	public Antenna rightAntenna;

	// keep track of where the agent has been for data logging:
	public ArrayList<String[]> positionDataList = new ArrayList<String[]>();

	// Immutable settings (per trial):
	protected final AgentProperties agentProp;
	protected final WorldProperties worldProp;

	// keep track of what the agent is doing for outside methods:
	public boolean walkerRunning = true; // false = end trial
	public boolean foundSource = false;
	public boolean timeout = false;
	public double secondsSinceStart = 0;

	// other utilities:
	protected Random rand = new Random();

	public Walker(AgentProperties agentProp_, WorldProperties worldProp_) throws DatatypeConfigurationException {
		// TODO Auto-generated constructor stub

		// make a local copy of the parameters
		agentProp = agentProp_;
		worldProp = worldProp_;

		// set up body position:
		headPt = new PVector(0.05 * worldProp.width, worldProp.height / 2);
		tailPt = new PVector(0, 0);
		updateTailPoint();

		// set up the antennae:
		leftAntenna = new Antenna(agentProp.l_antennaLength, headPt, theta, -Math.PI / 2, -Math.PI / 4,
				agentProp.headDiameter / 2, agentProp.detectionThreshold);
		rightAntenna = new Antenna(agentProp.r_antennaLength, headPt, theta, Math.PI / 2, Math.PI / 4,
				agentProp.headDiameter / 2, agentProp.detectionThreshold);

	}

	public abstract void adjustAngularVelocity(); // this needs to be
													// instantiated by each
													// sub-class

	public void saveData(String fname, int n) throws IOException {
		// format the trial number to three digits:
		if (n < 10) {
			fname = fname + "00" + Integer.toString(n);
		} else if (n < 100) {
			fname = fname + "0" + Integer.toString(n);
		} else {
			fname = fname + Integer.toString(n);
		}

		// save antenna data:
		leftAntenna.writeData2File(fname + "_leftAntenna");
		rightAntenna.writeData2File(fname + "_rightAntenna");

		// save body position:
		fname = fname + "_bodyPts.csv"; // append a file extension
		CSVWriter writer = new CSVWriter(new FileWriter(fname));
		writer.writeAll(positionDataList);
		writer.close();

	}

	public void startTracking() {

		speed = 23;
	}

	public void step() throws DatatypeConfigurationException {
		theta += (omega * agentProp.heuristic_gainFactor + rand.nextGaussian() * agentProp.random_gainFactor)
				* worldProp.dt; // add
		// angular
		// velocity
		// to
		// angle
		wrapTheta(); // make sure theta stays within +/- Pi

		// create a velocity vector to determine where to move the head point
		PVector stepVelocity = new PVector(speed * worldProp.dt * Math.cos(theta),
				speed * worldProp.dt * Math.sin(theta));

		// update body position:
		headPt.add(stepVelocity);
		updateTailPoint();

		// update antenna positions
		leftAntenna.updatePosition(headPt, theta);
		rightAntenna.updatePosition(headPt, theta);

		// update time
		secondsSinceStart += worldProp.dt;

		// check for termination conditions:
		checkExitArena();
		checkFoundSource();
		checkTimeout();

		// add position info to table:
		Double[] points = { headPt.x, headPt.y, tailPt.x, tailPt.y };
		String s = Arrays.toString(points); // create a string representation
		s = s.substring(1, s.length() - 1); // cut off square brackets at the
											// ends
		positionDataList.add(s.split(",")); // split the string with a ", "
											// delimiter

	}

	public abstract String talk(); // returns a string identifying the heuristic
									// for logging data to file

	public void updateAntennalMap(ArrayList<OdorParticle> plume) throws DatatypeConfigurationException {
		leftAntenna.applyOdor2Map(plume);
		rightAntenna.applyOdor2Map(plume);
	}

	public void wrapTheta() {
		// wrap theta to +/- Pi

		if (theta > Math.PI) {
			theta -= 2 * Math.PI;
			// System.out.println("too big:" + theta);
		} else if (theta < -Math.PI) {
			theta += 2 * Math.PI;
			// System.out.println("too small: " + theta);
		}

	}

	private void checkExitArena() {
		if (headPt.x > worldProp.width | headPt.x < 0) {
			walkerRunning = false;
		} else if (headPt.y > worldProp.height | headPt.y < 0) {
			walkerRunning = false;
		}
	}

	private void checkFoundSource() throws DatatypeConfigurationException {
		if (headPt.distance(worldProp.source) <= agentProp.bodyLength * 2) {
			walkerRunning = false;
			foundSource = true;
		}
	}

	private void checkTimeout() {
		// 300 s = 5 minutes, the limit in the behavior experiments
		if (secondsSinceStart > 300) {
			timeout = true;
			walkerRunning = false;
		}

	}

	// concrete methods:
	private void updateTailPoint() {
		tailPt.x = headPt.x - (agentProp.bodyLength) * Math.cos(theta);
		tailPt.y = headPt.y - (agentProp.bodyLength) * Math.sin(theta);
	}

}
