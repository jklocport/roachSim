package bio.jkl.walker.biology;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.xml.datatype.DatatypeConfigurationException;

import com.opencsv.CSVWriter;

import bio.jkl.walker.physics.OdorParticle;
import bio.jkl.walker.physics.PVector;

/*
 * The body is modeled as a T with the antennae sticking off the tips of the T
 * 
 */

public class Antenna {

	public int length; // number of bins
	private double headBaseAngle;// angle from front of head to antenna base
									// (should be +/- Pi/2)
	public double antennaAngle; // angle antenna is stick out at, 0 would be
								// straight ahead
	public double headRadius;
	public double[] odorMap;
	public PVector base;
	public PVector tip;
	public double odorThreshold;
	public ArrayList<String[]> antennaDataList;

	public Antenna(int length_, PVector headPoint_, double headding_, double headBaseAngle_, double angleOffset_,
			double headRadius_, double odorThreshold_) throws DatatypeConfigurationException {
		// TODO Auto-generated constructor stub
		length = length_;
		headBaseAngle = headBaseAngle_;
		antennaAngle = angleOffset_;
		headRadius = headRadius_;
		odorThreshold = odorThreshold_;

		base = new PVector(0, 0);
		tip = new PVector(0, 0);

		updatePosition(headPoint_, headding_); // set an initial position

		// Initialize odorMap with zeros
		odorMap = new double[40];
		clearMap();

		antennaDataList = new ArrayList<String[]>();
	}

	public void updatePosition(PVector headPoint_, double headding_) {
		// move the points marking the base and tip of the antenna
		base.x = headPoint_.x + headRadius * Math.cos(headding_ + headBaseAngle);
		base.y = headPoint_.y + headRadius * Math.sin(headding_ + headBaseAngle);

		tip.x = base.x + length * Math.cos(headding_ + antennaAngle);
		tip.y = base.y + length * Math.sin(headding_ + antennaAngle);
	}

	public void applyOdor2Map(ArrayList<OdorParticle> plume) throws DatatypeConfigurationException {
		OdorParticle op;
		clearMap();

		// iterate over all the odor particles in the plume
		for (int i = 0; i < plume.size(); i++) {
			op = plume.get(i); // get odor particle

			int[] index = getIndices(op); // get the intersection points

			// add the odor to the map, skipping the loop if the indices are
			// equal (nothing inside the odor particle)
			if (index[0] != index[1]) {
				for (int j = index[0]; j <= index[1]; j++) {
					odorMap[j] += op.concentration;
				}
			}
		}

		// handle the odor OnOff case:
		if (odorThreshold != 0) {
			for (int i = 0; i < length; i++) {
				if (odorMap[i] >= odorThreshold) {
					odorMap[i] = 1;
				} else {
					odorMap[i] = 0;
				}

			}
		}

		// add odor info to table:
		String s = Arrays.toString(odorMap); // create a string representation
		s = s.substring(1, s.length() - 1); // cut off square brackets at the
											// ends
		antennaDataList.add(s.split(",")); // split the string with a ", "
											// delimiter

	}

	public double getMassByDistance() {
		/*
		 * Center of Mass Equation:
		 * 
		 * R = 1/M*sum(mi*ri);
		 * 
		 * Where R is the coordinate of the COM
		 * 
		 * M is the total mass
		 * 
		 * mi is the mass at the ith coordinate
		 * 
		 * ri is the ith coordinate
		 */

		double sumMiRi = 0;

		for (int i = 0; i < length; i++) {
			sumMiRi += odorMap[i] * i;
		}

		return sumMiRi;
	}

	public double getOdorTotal() {
		double total = 0;
		for (int i = 0; i < length; i++) {
			total += odorMap[i];
		}
		return total;
	}

	public void clearMap() {
		for (int i = 0; i < length; i++) {
			odorMap[i] = 0;
		}
	}

	private int[] getIndices(OdorParticle op) throws DatatypeConfigurationException {
		int index1;
		int index2;

		ArrayList<PVector> crossPoints = getCircleLineIntersectionPoint(base, tip, op.center, op.radius);
		PVector pt1 = crossPoints.get(0);

		if (crossPoints.size() == 1) {
			// either the line ends in the circle, or it never intersects
			if (pt1.x < 0) { // function should return a 1d PVector with -1 if
								// there is no intersection
				if (op.center.distance(base) <= op.radius && op.center.distance(tip) <= op.radius) {
					// antenna fully inside
					index1 = 0;
					index2 = length - 1;
				} else {
					// antenna fully outside
					index1 = 0;
					index2 = 0;
				}
			} else {
				// one end must be inside, the other outside
				if (op.center.distance(base) <= op.radius) {
					// base inside
					index1 = 0;
					index2 = (int) base.distance(pt1);
				} else {
					// tip inside
					index1 = length - 1 - (int) tip.distance(pt1);
					index2 = length - 1;
				}
			}

		} else { // antenna pass through
			PVector pt2 = crossPoints.get(1);
			index1 = (int) base.distance(pt1);
			index2 = (int) base.distance(pt2);
		}

		// make sure nothing funny happens because of round-off error
		if (index1 < 0) {
			index1 = 0;
		} else if (index1 > length - 1) {
			index1 = length - 1;
		}
		if (index2 < 0) {
			index2 = 0;
		} else if (index2 > length - 1) {
			index2 = length - 1;
		}
		return new int[] { index1, index2 };
	}

	private static ArrayList<PVector> getCircleLineIntersectionPoint(PVector pointA, PVector pointB, PVector center,
			double radius) {

		// code modified from:
		// http://stackoverflow.com/questions/13053061/circle-line-intersection-points

		ArrayList<PVector> points = new ArrayList<PVector>();// create a list of
																// PVectors

		double baX = pointB.x - pointA.x;
		double baY = pointB.y - pointA.y;
		double caX = center.x - pointA.x;
		double caY = center.y - pointA.y;

		double a = baX * baX + baY * baY;
		double bBy2 = baX * caX + baY * caY;
		double c = caX * caX + caY * caY - radius * radius;

		double pBy2 = bBy2 / a;
		double q = c / a;

		double disc = pBy2 * pBy2 - q;
		if (disc < 0) {
			points.add(new PVector(-1));
			return points;
		}
		// if disc == 0 ... dealt with later
		double tmpSqrt = Math.sqrt(disc);
		double abScalingFactor1 = -pBy2 + tmpSqrt;
		double abScalingFactor2 = -pBy2 - tmpSqrt;

		PVector p1 = new PVector(pointA.x - baX * abScalingFactor1, pointA.y - baY * abScalingFactor1);
		points.add(p1);
		if (disc == 0) { // abScalingFactor1 == abScalingFactor2
			return points;
		}
		PVector p2 = new PVector(pointA.x - baX * abScalingFactor2, pointA.y - baY * abScalingFactor2);
		points.add(p2);

		return points;
	}

	public void writeData2File(String fname) throws IOException {
		fname = fname + ".csv"; // append a file extension
		CSVWriter writer = new CSVWriter(new FileWriter(fname));
		writer.writeAll(antennaDataList);
		writer.close();
	}

}
