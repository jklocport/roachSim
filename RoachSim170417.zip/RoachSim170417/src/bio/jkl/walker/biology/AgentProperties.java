package bio.jkl.walker.biology;

import java.io.IOException;
import java.util.List;

import bio.jkl.walker.utils.CSVTable;

public class AgentProperties {

	/*
	 * The purpose here is to have a object that holds a collection of
	 * parameters and can be passed around
	 */

	// body geometry
	public int r_antennaLength;
	public int l_antennaLength;
	public double headDiameter;
	public double bodyLength;

	// how odor information is handled
	public boolean odorONOFF;
	public double decayRate;
	public double evidenceThreshold;
	public double detectionThreshold;
	public double heuristic_gainFactor;
	public double random_gainFactor;

	// important values from Lockey & Willis 2015:
	public double ave_ang_vel;
	public double std_ang_vel;
	public double max_ang_vel;
	public double ave_ang_acl;
	public double std_ang_acl;
	public double max_ang_acl;

	private String antennaLengthsCSVFile = "/home/jacob/Dropbox/Programs/eclipse_java/RoachSim170417/inputDataFiles/antLengths.csv";
	private String gainFactorsCSVFile = "/home/jacob/Dropbox/Programs/eclipse_java/RoachSim170417/inputDataFiles/gainFactors.csv";

	private List<String[]> antennaLengthsList = new CSVTable(antennaLengthsCSVFile).entries;
	private List<String[]> gainFactorsList = new CSVTable(gainFactorsCSVFile).entries;
	public double n_antennaLengths = antennaLengthsList.size();
	public double n_gainFactors = gainFactorsList.size();

	public AgentProperties() throws IOException {
		// body geometry
		r_antennaLength = 40; // mm
		l_antennaLength = 40; // mm
		headDiameter = 3.278; // mm
		bodyLength = 40; // mm

		// how odor information is handled
		odorONOFF = true;
		decayRate = 0.90; // % of previous
		evidenceThreshold = 1; // units?
		// TODO: pick a good threshold
		detectionThreshold = 0.01; // units? (based on voltages from PID)
		heuristic_gainFactor = 0.5; // 0-1
		random_gainFactor = 0.5; // 0-1

		// important values from Lockey & Willis 2015:
		ave_ang_vel = 6.54 * Math.PI / 180; // deg/s -> rad/s
		std_ang_vel = 22.8 * Math.PI / 180; // deg/s -> rad/s
		max_ang_vel = ave_ang_vel + 3 * std_ang_vel; // rad/s
		ave_ang_acl = 4.24 * Math.PI / 180; // deg/s^2 -> rad/s^2
		std_ang_acl = 9.91 * Math.PI / 180; // deg/s^2 -> rad/^s2
		max_ang_acl = ave_ang_acl + 3 * std_ang_acl; // rad/s^2
		/*
		 * Note: from searching the data set, the max_angVel was 64.3193 deg/s
		 * here, it equals 74.94 deg/s max_angAcl from data: 31.5974 deg/s^2
		 * here, it's 33.97 deg/s^2
		 */

	}

	public void setAntennaLength(int i) {
		// pull the antenna treatment from the list of antenna treatments
		r_antennaLength = Integer.parseInt(antennaLengthsList.get(i)[0]); // mm
		l_antennaLength = Integer.parseInt(antennaLengthsList.get(i)[1]); // mm
		// System.out.println(r_antennaLength + "," + l_antennaLength);
	}

	public void setGainFactors(int i) {
		// pull the gain factor combo from the table of gain factors
		heuristic_gainFactor = Double.parseDouble(gainFactorsList.get(i)[0]);
		random_gainFactor = Double.parseDouble(gainFactorsList.get(i)[1]);
	}

}
